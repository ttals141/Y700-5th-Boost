#!/system/bin/sh
# =====================================================================
# Y700 5th Boost 工具箱（v1.10）
# 用法：su -c sh /sdcard/Y700G5_工具/tools.sh
# 卸载模块后仍然可用（脚本与 lib 会在每次开机时复制到 /sdcard）
# =====================================================================
SELF=${0%/*}
MODDIR=${Y7_MODDIR:-/data/adb/modules/y700g5_gpu1200}
BK=${Y7_BACKUP_DIR:-/data/adb/y700g5_backup}
SD=/sdcard/Y700G5_工具
STOCKFILE="$MODDIR/stock.md5"
TASS=/data/data/com.zui.tassistent/files/gameperfconfig.xml

LIB="$SELF/lib/rebuild.sh"
[ -f "$LIB" ] || LIB="$MODDIR/lib/rebuild.sh"
if [ ! -f "$LIB" ]; then echo "找不到 lib/rebuild.sh，无法继续"; exit 1; fi
. "$LIB"

md5of() { md5sum "$1" 2>/dev/null | cut -d' ' -f1; }
read_stock() { awk -v k="$1" '$2==k{print $1; exit}' "$STOCKFILE" 2>/dev/null; }
line() { echo "------------------------------------------------------------"; }

ENTRIES="xml:/system/etc/gameperfconfig.xml
gpu_0:/system/vendor/etc/thermal-engine_gpu_0.conf
gpu_1:/system/vendor/etc/thermal-engine_gpu_1.conf
gpu_2:/system/vendor/etc/thermal-engine_gpu_2.conf
gpu_5:/system/vendor/etc/thermal-engine_gpu_5.conf"

do_status() {
  line
  if [ -f "$MODDIR/module.prop" ]; then
    echo "模块：$(grep -E '^version=' "$MODDIR/module.prop" | cut -d= -f2-)  ($(grep -E '^versionCode=' "$MODDIR/module.prop" | cut -d= -f2-))"
    echo "状态：xml_state = $(cat "$MODDIR/xml_state" 2>/dev/null || echo '无')"
    echo "在用的 XML：$(cat "$MODDIR/xml_src" 2>/dev/null || echo '未挂载')"
  else
    echo "模块：未安装"
  fi
  line
  printf "%-7s %-34s %-34s %s\n" "项" "当前文件 md5" "原厂 md5" "判定"
  echo "$ENTRIES" | while IFS=: read -r k path; do
    [ -z "$k" ] && continue
    cur=$(md5of "$path"); st=$(read_stock "$k"); our=$(md5of "$MODDIR${path}")
    bld=$(md5of "$MODDIR/build/$k")
    if [ -z "$cur" ]; then verdict="文件不存在"
    elif [ "$cur" = "$st" ]; then verdict="原厂"
    elif [ -n "$our" ] && [ "$cur" = "$our" ]; then verdict="模块版"
    elif [ -n "$bld" ] && [ "$cur" = "$bld" ]; then verdict="重建版（待重启生效）"
    else verdict="未知（新固件或被覆盖）"; fi
    printf "%-7s %-34s %-34s %s\n" "$k" "${cur:-none}" "${st:-none}" "$verdict"
  done
  line
  echo "助手副本：$(md5of "$TASS" 2>/dev/null || echo '不存在')  (期望 $(md5of "$MODDIR/system/etc/gameperfconfig.xml" 2>/dev/null || echo '?'))"
  echo "GPU 上限：max_pwrlevel=$(cat /sys/class/kgsl/kgsl-3d0/max_pwrlevel 2>/dev/null)  (0 = 已放开)"
  line
  echo "备份目录：$BK"
  ls "$BK" 2>/dev/null | sed 's/^/  /'
  line
}

do_export() {
  if [ ! -d "$BK" ]; then echo "还没有备份（模块从没正常挂载过？）"; return; fi
  mkdir -p "$SD/backup" 2>/dev/null
  n=0
  for f in "$BK"/*.orig; do
    [ -f "$f" ] || continue
    cp -f "$f" "$SD/backup/" && n=$((n+1))
  done
  echo "已导出 $n 个文件到 $SD/backup/"
  ls "$SD/backup" 2>/dev/null | sed 's/^/  /'
}

do_restore_copy() {
  line
  if [ -f "$MODDIR/module.prop" ] && [ "$(cat "$MODDIR/xml_state" 2>/dev/null)" = "ok" ]; then
    echo "⚠ 模块还在工作。现在还原副本，下次开机又会被同步回模块版。"
    echo "  正确顺序：先在 KernelSU 里卸载模块 → 重启 → 再运行本项。"
    line
    return
  fi
  if [ ! -f "$TASS" ]; then echo "助手副本不存在，无需处理"; return; fi
  echo "将把 /system/etc/gameperfconfig.xml 写回助手副本："
  echo "  当前副本：$(md5of "$TASS")"
  echo "  将变成　：$(md5of /system/etc/gameperfconfig.xml)"
  printf "确认？(y/N) "; read -r a
  [ "$a" = "y" ] || [ "$a" = "Y" ] || { echo "已取消"; return; }
  cp -f /system/etc/gameperfconfig.xml "$TASS" || { echo "写入失败"; return; }
  chown system:system "$TASS" 2>/dev/null
  chmod 600 "$TASS" 2>/dev/null
  echo "完成：$(md5of "$TASS")"
}

do_rebuild() {
  line
  if [ ! -f "$MODDIR/module.prop" ]; then echo "模块未安装，无法重建"; return; fi
  busy=0
  echo "$ENTRIES" | while IFS=: read -r k path; do
    [ -z "$k" ] && continue
    cur=$(md5of "$path"); our=$(md5of "$MODDIR${path}")
    if [ -z "$cur" ]; then echo "  $k：文件不存在，跳过"; continue; fi
    if [ -n "$our" ] && [ "$cur" = "$our" ]; then
      echo "  $k：仍被模块覆盖 —— 先重启让模块让位（xml_state 应为 skip）后再运行"
      continue
    fi
    mkdir -p "$MODDIR/build"
    if [ "$k" = "xml" ]; then rb_xml "$path" "$MODDIR/build/$k.new"; else rb_conf "$path" "$MODDIR/build/$k.new"; fi
    if [ $? -eq 0 ]; then
      mv -f "$MODDIR/build/$k.new" "$MODDIR/build/$k"
      echo "$cur" > "$MODDIR/build/$k.src"
      echo "  $k：已重建"
      ACCF="$MODDIR/accepted.md5"
      : > "$ACCF.tmp"
      [ -f "$ACCF" ] && awk -v kk="$k" '$2 != kk' "$ACCF" >> "$ACCF.tmp"
      echo "$cur  $k" >> "$ACCF.tmp"
      mv -f "$ACCF.tmp" "$ACCF" 2>/dev/null
    else
      echo "  $k：重建失败（结构不符），保持原样"
    fi
  done
  line
  echo "重建完成后重启手机即可生效。"
  line
}

do_help() {
  line
  cat <<'H'
这个模块做了三件事：
  1. 把野兽 / SR野兽 / FI野兽 / SR-FI野兽 四种模式的 GPU 上限抬到 1200MHz（17_0）
  2. 把温度墙后移（游戏走 gpu_2：48/50/52/54 -> 59/62/65/68℃；
     非游戏走 gpu_0：44/46/48/50 -> 55/58/61/64℃）
  3. 直接改写「游戏助手」的配置副本（它读的是 /data 下自己那份，不认 /system）

本工具能做什么：
  1 状态检查 —— 看模块是否在正常工作、文件到底是原厂还是模块版
  2 导出备份 —— 把开机时自动抓的原厂文件复制到 /sdcard
  3 清理残留 —— 卸载模块后把助手副本还原成原厂
  4 重建     —— 系统更新后，用新固件重新生成模块文件

重要顺序：
  卸载模块 → 重启 → 再运行「3 清理残留」
  系统更新  → 重启（模块会自动让位）→ 运行「4 重建」→ 再重启
H
  line
}

while :; do
  echo
  echo "===== Y700 5th Boost 工具 v1.10 ====="
  echo " 1) 状态检查"
  echo " 2) 导出原厂备份到 /sdcard"
  echo " 3) 卸载后清理残留（还原助手副本）"
  echo " 4) 系统更新后重建"
  echo " 5) 说明"
  echo " 0) 退出"
  printf "选择："
  read -r c
  case "$c" in
    1) do_status ;;
    2) do_export ;;
    3) do_restore_copy ;;
    4) do_rebuild ;;
    5) do_help ;;
    0) exit 0 ;;
    *) echo "无效输入" ;;
  esac
done
