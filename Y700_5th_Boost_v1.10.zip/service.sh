#!/system/bin/sh
# Y700 5th Boost —— 开机 45 秒兜底（v1.10）
# 1) 补一次助手副本同步（post-fs-data 阶段 /data/data 通常还没挂上）
# 2) 把 tools.sh 与 lib 复制到 /sdcard，卸载后仍可用
MODDIR=${0%/*}
[ -f "$MODDIR/module.prop" ] || MODDIR=/data/adb/modules/y700g5_gpu1200
LOG="$MODDIR/sync.log"
log() { echo "$(date '+%F %T') $1" >> "$LOG"; }

sleep 45

STATE=$(cat "$MODDIR/xml_state" 2>/dev/null)
if [ "$STATE" != "ok" ]; then
  log "xml_state=$STATE，跳过助手副本同步"
else
  TASS="/data/data/com.zui.tassistent/files/gameperfconfig.xml"
  SRC=$(cat "$MODDIR/xml_src" 2>/dev/null)
  if [ -n "$SRC" ] && [ -f "$SRC" ] && [ -f "$TASS" ]; then
    if [ "$(md5sum "$TASS" 2>/dev/null | cut -d' ' -f1)" = "$(md5sum "$SRC" 2>/dev/null | cut -d' ' -f1)" ]; then
      log "ok, 助手副本已是最新"
    else
      if cp -f "$SRC" "$TASS" 2>/dev/null; then
        chown system:system "$TASS" 2>/dev/null
        chmod 0600 "$TASS" 2>/dev/null
        log "resynced -> $(md5sum "$SRC" | cut -d' ' -f1)"
      else
        log "写入副本失败"
      fi
    fi
  else
    log "助手副本不存在或源文件缺失，跳过"
  fi
fi

# 复制工具到 /sdcard
if [ -d /sdcard ]; then
  SD=/sdcard/Y700G5_工具
  mkdir -p "$SD/lib" 2>/dev/null
  cp -f "$MODDIR/tools.sh" "$SD/tools.sh" 2>/dev/null
  cp -f "$MODDIR/lib/rebuild.sh" "$SD/lib/rebuild.sh" 2>/dev/null
  chmod 755 "$SD/tools.sh" 2>/dev/null
  log "工具已复制到 $SD"
fi
