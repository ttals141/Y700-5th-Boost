# =====================================================================
# Y700 5th Boost —— 重建核心
# 被 post-fs-data.sh 与 tools.sh 共同 source
#   1) rb_xml  : 四种高性能模式的 Gpu 一律改成 17_0（上限 1200MHz，下限降到最低档 160MHz）
#   2) rb_conf : 第 1/2/3/4 档 set_point 依次 +11/+12/+13/+14℃，clr 同步平移
# 两个函数都自带输出校验，校验不过返回非 0，调用方必须按失败处理
# =====================================================================

# ---------- XML ----------
rb_xml() {
  awk '
  {
    line=$0
    if (line ~ /<Mode name=/) { match(line,/name="[^"]*"/); mode=substr(line,RSTART+6,RLENGTH-7) }
    else if (line ~ /<\/Mode>/) { mode="" }
    if (line ~ /<SceneOpt>/) { insc=1; mode="" }
    if (line ~ /<\/SceneOpt>/) { insc=0 }
    if (index(line, "name=\"Gpu\">") > 0) {
      p=index(line,"name=\"Gpu\">"); s=substr(line,p+11); q=index(s,"<"); v=substr(s,1,q-1)
      us=index(v,"_"); f1=substr(v,1,us-1)
      doit=0
      if (mode=="Savage"||mode=="SR_Savage"||mode=="FI_Savage"||mode=="SR_FI_Savage") doit=1
      else if (insc==1 && f1 != "0") doit=1
      if (doit==1 && v != "17_0") {
        line=substr(line,1,p+10) "17_0</item>" substr(line, p+10+length(v)+8)
      }
    }
    print line
  }
  ' "$1" > "$2" || { echo "rb_xml: awk 执行失败"; return 1; }
  rb_verify_xml "$2"
}

rb_verify_xml() {
  awk '
  {
    if ($0 ~ /<Mode name=/) { match($0,/name="[^"]*"/); m=substr($0,RSTART+6,RLENGTH-7) }
    else if ($0 ~ /<\/Mode>/) { m="" }
    if ($0 ~ /<SceneOpt>/) { insc=1; m="" }
    if ($0 ~ /<\/SceneOpt>/) { insc=0 }
    if (index($0,"name=\"Gpu\">") > 0) {
      p=index($0,"name=\"Gpu\">"); s=substr($0,p+11); q=index(s,"<"); v=substr(s,1,q-1)
      if (m=="Savage"||m=="SR_Savage"||m=="FI_Savage"||m=="SR_FI_Savage") { t++; if (v!="17_0") bad++ }
      else if (insc==1) { us=index(v,"_"); f1=substr(v,1,us-1); if (f1!="0") { sc++; if (v!="17_0") bad++ } }
    }
    if (index($0,"</GameOptPolicy>") > 0) endok=1
  }
  END {
    if (!endok) { print "校验失败: 缺少 </GameOptPolicy>"; exit 1 }
    if (t == 0) { print "校验失败: 未找到目标模式的 Gpu 条目"; exit 1 }
    if (bad > 0) { printf "校验失败: 仍有 %d 条 Gpu 不是 17_0\n", bad; exit 1 }
    printf "校验通过: 模式 %d 条 / 场景 %d 条\n", t, sc
  }
  ' "$1"
}

# ---------- 温控 ----------
rb_conf() {
  awk '
  BEGIN { o[1]=11000; o[2]=12000; o[3]=13000; o[4]=14000 }
  /^\[/ { bi++ }
  /^set_point/ {
    v=$NF+0
    nv=v+o[bi]
    sub(/[0-9]+$/, nv)
    print
    n++
    next
  }
  { print }
  ' "$1" > "$2" || { echo "rb_conf: awk 执行失败"; return 1; }
  rb_verify_conf "$1" "$2"
}

rb_verify_conf() {
  a=$(grep -c '^\[SS-GPU-' "$1" 2>/dev/null)
  b=$(grep -c '^\[SS-GPU-' "$2" 2>/dev/null)
  n=$(grep -c '^set_point' "$2" 2>/dev/null)
  if [ "$a" != "$b" ]; then echo "校验失败: 块数 $a -> $b"; return 1; fi
  if [ -z "$n" ] || [ "$n" -lt 1 ]; then echo "校验失败: 没有 set_point"; return 1; fi
  echo "校验通过: 块 $b 个 / set_point $n 条"
}
