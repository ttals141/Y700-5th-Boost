#!/system/bin/sh
# =====================================================================
# Y700 5th Boost —— 开机挂载（v1.10）
#   1. 目标文件 == 原厂记录      -> 备份一份，再用模块文件
#   2. 目标文件 == 模块文件      -> 直接用（幂等）
#   3. 目标文件 == 已确认固件    -> 用上次的重建结果（不再备份、不再报 UPDATED）
#   4. 都不是                    -> 多半是 OTA：备份 + 自动重建，成功后记入 accepted.md5
#   5. 目标被别的挂载盖住        -> 什么都不做（设备号不一致时判定为被覆盖）
#
# v1.10 的两处修正：
#   a) 重建结果要写回模块自己的 system/ 文件，不能只做 per-file bind mount。
#      KernelSU 的 overlay 在 post-fs-data 之后才挂载，会把 per-file bind 整个盖掉；
#      overlay 提供的是模块目录里的文件，所以只有写回那里才真正生效。
#   b) anchor 改用目标文件的绝对父目录，devof 加 -L，不再依赖当前工作目录。
# =====================================================================
MODDIR=${0%/*}
[ -f "$MODDIR/module.prop" ] || MODDIR=/data/adb/modules/y700g5_gpu1200
MODDIR=$(cd "$MODDIR" 2>/dev/null && pwd) || MODDIR=/data/adb/modules/y700g5_gpu1200
TP="${Y7_TARGET_ROOT:-}"
STOCKFILE="$MODDIR/stock.md5"
ACCFILE="$MODDIR/accepted.md5"
BUILD="$MODDIR/build"
BK="${Y7_BACKUP_DIR:-/data/adb/y700g5_backup}"
LOG="$MODDIR/mount.log"

if [ ! -f "$MODDIR/lib/rebuild.sh" ]; then
  echo "缺少 lib/rebuild.sh，模块无法工作" > "$LOG"
  echo skip > "$MODDIR/xml_state"
  exit 0
fi
. "$MODDIR/lib/rebuild.sh"

mkdir -p "$BUILD" "$BK" 2>/dev/null
: > "$LOG"

log()  { echo "$1" >> "$LOG"; }
md5of() { md5sum "$1" 2>/dev/null | cut -d' ' -f1; }
devof() { stat -L -c %d "$1" 2>/dev/null; }
read_stock() { awk -v k="$1" '$2==k{print $1; exit}' "$STOCKFILE" 2>/dev/null; }
read_accepted() { awk -v k="$1" '$2==k{print $1; exit}' "$ACCFILE" 2>/dev/null; }

write_accepted() {
  k="$1"; v="$2"
  : > "$ACCFILE.tmp"
  [ -f "$ACCFILE" ] && awk -v k="$k" '$2!=k' "$ACCFILE" >> "$ACCFILE.tmp"
  echo "$v  $k" >> "$ACCFILE.tmp"
  mv -f "$ACCFILE.tmp" "$ACCFILE" 2>/dev/null
}

backup_one() {
  k="$1"; s="$2"; c=$(md5of "$s")
  [ -z "$c" ] && return 0
  [ -f "$BK/$k.$c.orig" ] && return 0
  cp -f "$s" "$BK/$k.$c.orig" 2>/dev/null && log "BACKUP $k  $c"
}

rebuild_one() {
  case "$1" in
    xml) rb_xml "$2" "$3" ;;
    *)   rb_conf "$2" "$3" ;;
  esac
}

# 把重建结果写回模块自己的文件 —— overlay 最终提供的就是这个文件
# 旧的模块文件先留一份到 build/<key>.prev，出问题还能退回去
writeback() {
  k="$1"; s="$2"
  [ -z "$s" ] && return 0
  [ "$s" = "$OUR" ] && return 0
  [ -f "$s" ] || return 0
  [ -f "$OUR" ] || return 0
  [ "$(md5of "$s")" = "$(md5of "$OUR")" ] && return 0
  cp -f "$OUR" "$BUILD/$k.prev" 2>/dev/null
  if cp -f "$s" "$OUR" 2>/dev/null; then
    log "WRITEBACK $k -> 模块文件已更新（旧版留在 build/$k.prev）"
  else
    log "WRITEBACK $k 失败（$OUR 不可写？）"
  fi
}

LAST_OK=0
handle() {
  key="$1"; rel="$2"
  TARGET="$TP$rel"
  OUR="$MODDIR$rel"
  ANCHOR="${TARGET%/*}"
  LAST_OK=0

  if [ ! -f "$TARGET" ]; then log "SKIP   $key  (目标不存在)"; return; fi
  CUR=$(md5of "$TARGET")
  if [ -z "$CUR" ]; then log "SKIP   $key  (读不到内容)"; return; fi
  STOCK=$(read_stock "$key")
  ACC=$(read_accepted "$key")
  OURMD5=$(md5of "$OUR")

  if [ "$CUR" = "$STOCK" ]; then
    backup_one "$key" "$TARGET"
    SRC="$OUR"; WHY="原厂未变，备份已就绪"
  elif [ -n "$OURMD5" ] && [ "$CUR" = "$OURMD5" ]; then
    SRC="$OUR"; WHY="本来就是模块文件"
  elif [ -n "$ACC" ] && [ "$CUR" = "$ACC" ]; then
    # 这一版固件之前已经备份并重建过，直接复用，不再重复备份、不再记 UPDATED
    if [ -f "$BUILD/$key" ] && [ "$(cat "$BUILD/$key.src" 2>/dev/null)" = "$CUR" ]; then
      SRC="$BUILD/$key"; WHY="固件已确认，沿用重建结果"
    elif rebuild_one "$key" "$TARGET" "$BUILD/$key.new"; then
      mv -f "$BUILD/$key.new" "$BUILD/$key"
      echo "$CUR" > "$BUILD/$key.src"
      SRC="$BUILD/$key"; WHY="固件已确认，已重新生成"
    else
      log "SKIP   $key  (重建失败，保持让位)"; return
    fi
  else
    # 先确认目标没有被别的模块挂载盖住：比对目标文件与其绝对父目录的设备号
    D1=$(devof "$TARGET"); D2=$(devof "$ANCHOR")
    if [ -n "$D1" ] && [ -n "$D2" ] && [ "$D1" != "$D2" ]; then
      log "SKIP   $key  (被其它挂载覆盖: dev $D1 vs $D2)"; return
    fi
    backup_one "$key" "$TARGET"
    log "UPDATED $key  $CUR  (固件内容变了)"
    if [ -f "$BUILD/$key" ] && [ "$(cat "$BUILD/$key.src" 2>/dev/null)" = "$CUR" ]; then
      SRC="$BUILD/$key"; WHY="沿用上次重建结果"
    elif rebuild_one "$key" "$TARGET" "$BUILD/$key.new"; then
      mv -f "$BUILD/$key.new" "$BUILD/$key"
      echo "$CUR" > "$BUILD/$key.src"
      SRC="$BUILD/$key"; WHY="已自动重建"
    else
      log "SKIP   $key  (重建失败，保持让位)"; return
    fi
    write_accepted "$key" "$CUR"
  fi

  # 关键：重建结果写回模块文件，overlay 才会提供新内容
  writeback "$key" "$SRC"
  SRC="$OUR"

  # 让模块文件的标签/权限跟原厂目标一致（bind mount 显示的是源文件的标签）
  if [ -f "$TARGET" ]; then
    chcon --reference="$TARGET" "$OUR" 2>/dev/null
    chmod 0644 "$OUR" 2>/dev/null
  fi

  if mount --bind "$SRC" "$TARGET" 2>/dev/null; then
    log "OK     $key  ($WHY)"
    [ "$key" = "xml" ] && echo "$SRC" > "$MODDIR/xml_src"
    LAST_OK=1
  else
    log "FAIL   $key  (bind 挂载失败)"
  fi
}

log "=== post-fs-data $(date +%H:%M:%S) ==="
handle xml   "/system/etc/gameperfconfig.xml"
XML_OK=$LAST_OK
handle gpu_0 "/system/vendor/etc/thermal-engine_gpu_0.conf"
handle gpu_1 "/system/vendor/etc/thermal-engine_gpu_1.conf"
handle gpu_2 "/system/vendor/etc/thermal-engine_gpu_2.conf"
handle gpu_5 "/system/vendor/etc/thermal-engine_gpu_5.conf"

if [ "$XML_OK" = "1" ]; then echo ok > "$MODDIR/xml_state"; else echo skip > "$MODDIR/xml_state"; rm -f "$MODDIR/xml_src"; fi

TASS="/data/data/com.zui.tassistent/files/gameperfconfig.xml"
if [ "$XML_OK" = "1" ] && [ -f "$TASS" ] && [ -f "$MODDIR/xml_src" ]; then
  if [ "$(md5of "$TASS")" = "$(md5of "$(cat "$MODDIR/xml_src")")" ]; then
    log "SYNC   助手副本已是最新"
  else
    if cp -f "$(cat "$MODDIR/xml_src")" "$TASS" 2>/dev/null; then
      chown system:system "$TASS" 2>/dev/null
      chmod 0600 "$TASS" 2>/dev/null
      log "SYNC   助手副本已同步"
    else
      log "SYNC   助手副本写入失败"
    fi
  fi
else
  log "SYNC   助手副本跳过（交给 service.sh 或 xml 未挂载）"
fi

log "--- 结束 xml_state=$(cat "$MODDIR/xml_state") ---"
