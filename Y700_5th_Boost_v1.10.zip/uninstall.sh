#!/system/bin/sh
# Y700 5th Boost —— 卸载时尽量还原（注意：KernelSU 3.3.1 不会执行本脚本）
MODDIR=${0%/*}
TASS=/data/data/com.zui.tassistent/files/gameperfconfig.xml
OUR="$MODDIR/system/etc/gameperfconfig.xml"
SRC="$MODDIR/backup/gameperfconfig.xml.orig"
[ -f "$TASS" ] && [ -f "$OUR" ] && [ -f "$SRC" ] || exit 0
CUR=$(md5sum "$TASS" | cut -d' ' -f1)
MINE=$(md5sum "$OUR" | cut -d' ' -f1)
if [ "$CUR" = "$MINE" ]; then
  cp -f "$SRC" "$TASS" && chown system:system "$TASS" 2>/dev/null && chmod 600 "$TASS" 2>/dev/null
fi
exit 0
