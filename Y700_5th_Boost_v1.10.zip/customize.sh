#!/system/bin/sh
# =====================================================================
# Y700 5th Boost —— 安装期检查（v1.10）
# 只做检查与提示，不写任何系统文件
# =====================================================================
command -v ui_print >/dev/null 2>&1 || ui_print() { echo "$1"; }
command -v abort    >/dev/null 2>&1 || abort() { ui_print "! $1"; exit 1; }

ui_print " "
ui_print "*******************************"
ui_print "  Y700 5th Boost"
ui_print "  v1.10"
ui_print "*******************************"
ui_print " "

XML="$MODPATH/system/etc/gameperfconfig.xml"
CONFDIR="$MODPATH/system/vendor/etc"
BK="$MODPATH/backup/gameperfconfig.xml.orig"
STOCKF="$MODPATH/stock.md5"

[ -f "$XML" ] || abort "缺少 gameperfconfig.xml"
[ -d "$CONFDIR" ] || abort "缺少温控配置目录"
[ -f "$BK" ] || abort "缺少原厂 XML 备份"
[ -f "$STOCKF" ] || abort "缺少 stock.md5"
[ -f "$MODPATH/lib/rebuild.sh" ] || abort "缺少 lib/rebuild.sh"
[ -f "$MODPATH/tools.sh" ] || abort "缺少 tools.sh"

CONFN=$(ls "$CONFDIR"/*.conf 2>/dev/null | wc -l)
[ "$CONFN" = "4" ] || abort "温控文件应为 4 个，实际 $CONFN 个"

BKMD5=$(md5sum "$BK" | cut -d' ' -f1)
[ "$BKMD5" = "ce849bb0c9497faff1311f37fd2fd189" ] || abort "原厂备份 md5 不符（$BKMD5）"

STOCKN=$(grep -c . "$STOCKF" 2>/dev/null)
[ "$STOCKN" = "5" ] || abort "stock.md5 应有 5 行，实际 $STOCKN 行"

GAME=$(grep -c '<Game ' "$XML")
MODE=$(grep -c '<Mode ' "$XML")
FREQ=$(grep -c '<item type="freq"' "$XML")
FULL=$(grep -c 'name="Gpu">17_0<' "$XML")

ui_print "- 结构统计：Game=$GAME  Mode=$MODE  频点=$FREQ"
ui_print "- GPU 为 17_0 的条目：$FULL"
ui_print "- 温控配置：$CONFN 个"
ui_print "- 原厂 XML 备份：$BKMD5"

# 结构统计只提示，不中止 —— 系统更新后重建出来的包，数字本来就会变
if [ "$GAME" != "46" ] || [ "$MODE" != "237" ] || [ "$FREQ" != "2862" ]; then
  ui_print " "
  ui_print "! 注意：结构统计与出厂版本不同（46/237/2862）"
  ui_print "! 若这是系统更新后重建的包，属正常；否则请慎用。"
fi

SP0=$(awk '/^set_point[ ]/{print $2; exit}' "$CONFDIR/thermal-engine_gpu_0.conf" 2>/dev/null)
SP2=$(awk '/^set_point[ ]/{print $2; exit}' "$CONFDIR/thermal-engine_gpu_2.conf" 2>/dev/null)
if [ "$SP0" != "55000" ] || [ "$SP2" != "59000" ]; then
  ui_print "! 温控首档：gpu_0=$SP0  gpu_2=$SP2（出厂版为 55000/59000，重建包可能不同）"
fi

ui_print " "
ui_print "- 开机时脚本会做这些事："
ui_print "  · 检查 5 个目标文件是不是原厂"
ui_print "  · 是原厂 -> 先备份一份到 /data/adb/y700g5_backup"
ui_print "  · 再挂载模块文件；若发现固件已更新，会自动重建后挂载"
ui_print "  · 被别的模块占用时，让位不动"
ui_print "- 工具箱：/sdcard/Y700G5_工具/tools.sh（开机自动复制）"
ui_print " "

# --- SELinux 标签与权限（v1.10 补回：v1.3 有，v1.7 重写时丢了）---
if command -v set_perm_recursive >/dev/null 2>&1; then
  set_perm_recursive "$MODPATH/system/etc" 0 0 0755 0644 "u:object_r:system_file:s0" 2>/dev/null || true
  set_perm_recursive "$CONFDIR" 0 0 0755 0644 "u:object_r:vendor_configs_file:s0" 2>/dev/null || true
else
  chmod 0755 "$MODPATH/system/etc" "$CONFDIR" 2>/dev/null
  chmod 0644 "$XML" "$CONFDIR"/*.conf 2>/dev/null
fi
if command -v chcon >/dev/null 2>&1; then
  chcon u:object_r:system_file:s0 "$XML" 2>/dev/null
  chcon u:object_r:vendor_configs_file:s0 "$CONFDIR"/*.conf 2>/dev/null
fi

chmod 0755 "$MODPATH/post-fs-data.sh" "$MODPATH/service.sh" "$MODPATH/uninstall.sh" "$MODPATH/tools.sh" 2>/dev/null
chmod 0644 "$MODPATH/lib/rebuild.sh" "$MODPATH/stock.md5" 2>/dev/null
ui_print "- 安装完成，请重启"
ui_print " "
